#!/bin/bash
# deploy.sh — Hub Faturamento CliqueDF
# Rodar no VPS: bash deploy.sh

set -e

DIR="/opt/automacoes/cliquedf/faturamento"
SERVICE="hubfaturamento_cliquedf"

echo "=== Hub Faturamento — Deploy ==="

# Cria diretório
mkdir -p $DIR/static $DIR/app/core $DIR/app/routes $DIR/app/services $DIR/app/bootstrap

# Copia arquivos (assumindo que você fez upload ou git clone)
echo "[1/5] Copiando arquivos..."

# Venv
echo "[2/5] Criando virtualenv..."
if [ ! -d "$DIR/venv" ]; then
  python3 -m venv $DIR/venv
fi

echo "[3/5] Instalando dependências..."
$DIR/venv/bin/pip install --upgrade pip -q
$DIR/venv/bin/pip install -r $DIR/requirements.txt -q

# Serviço systemd
echo "[4/5] Instalando serviço systemd..."
cp $DIR/hubfaturamento_cliquedf.service /etc/systemd/system/
systemctl daemon-reload
systemctl enable $SERVICE

echo "[5/5] Iniciando serviço..."
systemctl restart $SERVICE
sleep 2
systemctl status $SERVICE --no-pager

echo ""
echo "=== Deploy concluído! ==="
echo "URL: http://191.252.196.225:8010"
echo "Logs: journalctl -u $SERVICE -f"
