# -*- coding: utf-8 -*-
from fastapi import APIRouter, HTTPException, Depends
from pydantic import BaseModel
from datetime import datetime
from app.core.db   import get_conn
from app.core.auth import hash_senha, criar_token, requer_admin, get_usuario_atual

router = APIRouter(prefix="/api/auth")

class LoginIn(BaseModel):
    login: str
    senha: str

@router.post("/login")
def login(body: LoginIn):
    with get_conn() as conn:
        cur = conn.cursor()
        cur.execute("""
            SELECT u.id, u.nome, u.login, u.senha_hash, u.ativo,
                   g.nivel, g.nome AS grupo
            FROM hf_usuarios u
            JOIN hf_grupos g ON g.id = u.id_grupo
            WHERE u.login = ?
        """, (body.login,))
        row = cur.fetchone()

    if not row:
        raise HTTPException(status_code=401, detail="Usuário não encontrado")
    if not row["ativo"]:
        raise HTTPException(status_code=403, detail="Usuário inativo")
    if row["senha_hash"] != hash_senha(body.senha):
        raise HTTPException(status_code=401, detail="Senha incorreta")

    with get_conn() as conn:
        conn.execute("UPDATE hf_usuarios SET ultimo_acesso=? WHERE id=?",
                     (datetime.now(), row["id"]))
        conn.commit()

    token = criar_token({
        "sub":   str(row["id"]),
        "login": row["login"],
        "nome":  row["nome"],
        "nivel": row["nivel"],
        "grupo": row["grupo"],
    })
    return {"token": token, "nome": row["nome"], "nivel": row["nivel"], "grupo": row["grupo"]}

# ── USUÁRIOS (admin) ──────────────────────────────────────────

@router.get("/usuarios")
def listar_usuarios(user=Depends(requer_admin)):
    with get_conn() as conn:
        cur = conn.cursor()
        cur.execute("""
            SELECT u.id, u.nome, u.login, u.ativo, u.criado_em, u.ultimo_acesso,
                   g.nome AS grupo, g.nivel
            FROM hf_usuarios u
            JOIN hf_grupos g ON g.id = u.id_grupo
            ORDER BY u.nome
        """)
        rows = cur.fetchall()
    return {"usuarios": [dict(r) for r in rows]}

class UsuarioIn(BaseModel):
    nome:     str
    login:    str
    senha:    str = ""
    id_grupo: int = 1
    ativo:    int = 1

@router.post("/usuarios")
def criar_usuario(body: UsuarioIn, user=Depends(requer_admin)):
    if not body.senha:
        raise HTTPException(400, "Senha obrigatória")
    with get_conn() as conn:
        cur = conn.cursor()
        try:
            cur.execute("""
                INSERT INTO hf_usuarios (nome, login, senha_hash, id_grupo, ativo)
                VALUES (?, ?, ?, ?, ?)
            """, (body.nome, body.login, hash_senha(body.senha), body.id_grupo, body.ativo))
            conn.commit()
        except Exception:
            raise HTTPException(400, "Login já existe")
    return {"ok": True}

@router.put("/usuarios/{uid}")
def editar_usuario(uid: int, body: UsuarioIn, user=Depends(requer_admin)):
    with get_conn() as conn:
        cur = conn.cursor()
        if body.senha:
            cur.execute("""
                UPDATE hf_usuarios SET nome=?, login=?, senha_hash=?, id_grupo=?, ativo=?
                WHERE id=?
            """, (body.nome, body.login, hash_senha(body.senha), body.id_grupo, body.ativo, uid))
        else:
            cur.execute("""
                UPDATE hf_usuarios SET nome=?, login=?, id_grupo=?, ativo=?
                WHERE id=?
            """, (body.nome, body.login, body.id_grupo, body.ativo, uid))
        conn.commit()
    return {"ok": True}

@router.delete("/usuarios/{uid}")
def deletar_usuario(uid: int, user=Depends(requer_admin)):
    with get_conn() as conn:
        conn.execute("DELETE FROM hf_usuarios WHERE id=?", (uid,))
        conn.commit()
    return {"ok": True}

@router.get("/grupos")
def listar_grupos(user=Depends(requer_admin)):
    with get_conn() as conn:
        rows = get_conn().execute("SELECT * FROM hf_grupos ORDER BY nivel").fetchall()
    return {"grupos": [dict(r) for r in rows]}
