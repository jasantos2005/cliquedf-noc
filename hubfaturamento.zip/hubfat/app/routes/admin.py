# -*- coding: utf-8 -*-
from fastapi import APIRouter, HTTPException, Depends, Query
from pydantic import BaseModel
from typing import Optional
from datetime import datetime, date, timedelta
from app.core.auth   import requer_admin
from app.core.db     import get_conn
from app.core.db_ixc import conn_ixc
import os

router = APIRouter(prefix="/api/admin")

# ── APROVAÇÕES ────────────────────────────────────────────────

@router.get("/aprovacoes")
def listar_aprovacoes(user=Depends(requer_admin)):
    with get_conn() as conn:
        cur = conn.cursor()
        cur.execute("""
            SELECT id, mes_ref, created_by, created_at, qtd_itens, total_simulado
            FROM batch_run WHERE status='AGUARDANDO_APROVACAO'
            ORDER BY created_at DESC
        """)
        rows = cur.fetchall()
    return {"batches": [dict(r) for r in rows]}

class AprovarIn(BaseModel):
    batch_id: int
    acao:     str  # 'aprovar' | 'rejeitar'

@router.post("/aprovar")
def aprovar_batch(body: AprovarIn, user=Depends(requer_admin)):
    if body.acao not in ("aprovar", "rejeitar"):
        raise HTTPException(400, "Ação inválida")

    with get_conn() as conn:
        cur = conn.cursor()
        cur.execute("SELECT status, mes_ref FROM batch_run WHERE id=?", (body.batch_id,))
        row = cur.fetchone()
        if not row or row["status"] != "AGUARDANDO_APROVACAO":
            raise HTTPException(400, "Batch inválido ou já processado")
        mes_ref = row["mes_ref"]

    novo_status = "APROVADO" if body.acao == "aprovar" else "REJEITADO"

    with get_conn() as conn:
        conn.execute("""
            UPDATE batch_run SET status=?, approved_by=?, approved_at=? WHERE id=?
        """, (novo_status, user["login"], datetime.now(), body.batch_id))
        conn.commit()

    if body.acao == "aprovar":
        _aplicar_batch(body.batch_id, mes_ref, user["login"])

    return {"ok": True, "status": novo_status}

# Link direto do Telegram (GET com token)
@router.get("/aprovar-link")
def aprovar_link(
    batch_id: int,
    acao:     str,
    token:    str = Query(...),
):
    expected = os.getenv("TELEGRAM_APPROVE_TOKEN", "")
    if not expected or token != expected:
        raise HTTPException(403, "Token inválido")

    body = AprovarIn(batch_id=batch_id, acao=acao)

    class FakeUser:
        def __getitem__(self, k): return "telegram-bot" if k == "login" else 99
        def get(self, k, d=None): return self[k]

    # Reutiliza a lógica acima
    with get_conn() as conn:
        cur = conn.cursor()
        cur.execute("SELECT status, mes_ref FROM batch_run WHERE id=?", (batch_id,))
        row = cur.fetchone()
        if not row or row["status"] != "AGUARDANDO_APROVACAO":
            return {"ok": False, "detail": "Batch já processado ou não encontrado"}
        mes_ref = row["mes_ref"]

    novo_status = "APROVADO" if acao == "aprovar" else "REJEITADO"
    with get_conn() as conn:
        conn.execute("UPDATE batch_run SET status=?, approved_by=?, approved_at=? WHERE id=?",
                     (novo_status, "telegram-bot", datetime.now(), batch_id))
        conn.commit()

    if acao == "aprovar":
        _aplicar_batch(batch_id, mes_ref, "telegram-bot")

    return {"ok": True, "status": novo_status, "batch_id": batch_id}

def _aplicar_batch(batch_id: int, mes_ref: str, aprovador: str):
    """Aplica tipo_documento nos contratos e cria geracao_lote no IXC."""
    with get_conn() as conn:
        cur = conn.cursor()
        cur.execute("SELECT id_contrato FROM batch_items WHERE batch_id=?", (batch_id,))
        contratos = [r["id_contrato"] for r in cur.fetchall()]

        cur.execute("SELECT tipo_pessoa, id_tipo_cliente, tipo_documento FROM regras_fiscais WHERE ativo=1")
        regras = {(r["tipo_pessoa"], r["id_tipo_cliente"]): r["tipo_documento"] for r in cur.fetchall()}

    if not contratos:
        return

    # Aplica tipo_doc_opc no IXC
    with conn_ixc() as ixc:
        cur = ixc.cursor(dictionary=True)
        for id_contrato in contratos:
            cur.execute("""
                SELECT c.id_tipo_cliente, c.tipo_pessoa
                FROM cliente_contrato cc
                JOIN cliente c ON c.id = cc.id_cliente
                WHERE cc.id = %s
            """, (id_contrato,))
            row = cur.fetchone()
            if not row:
                continue
            tipo_doc = regras.get((row["tipo_pessoa"], row["id_tipo_cliente"]), 710)

            cur.execute("""
                UPDATE cliente_contrato
                SET tipo_doc_opc=NULL, tipo_doc_opc2=NULL, tipo_doc_opc3=NULL, tipo_doc_opc4=NULL
                WHERE id=%s
            """, (id_contrato,))
            cur.execute("UPDATE cliente_contrato SET tipo_doc_opc=%s WHERE id=%s",
                        (tipo_doc, id_contrato))

    # Cria geracao_lote no IXC
    with conn_ixc() as ixc:
        cur = ixc.cursor()
        cur.execute("SELECT COALESCE(MAX(id),0)+1 FROM geracao_lote")
        novo_lote_id = cur.fetchone()[0]

        hoje  = date.today()
        ano   = int(mes_ref[:4])
        mes   = int(mes_ref[5:])
        p_dia = date(ano, mes, 1)
        u_dia = (p_dia + timedelta(days=32)).replace(day=1) - timedelta(days=1)
        desc  = f"FAT. {mes_ref.replace('-','/')} - LOTE 1"

        cur.execute("""
            INSERT INTO geracao_lote
            (id, data_emissao_nf, mes_ano_referencia_nf, tipo_documento_opcional_nf,
             id_contrato_inicial_nf, id_contrato_final_nf, data_limite_inicio_contrato_nf,
             tipo_pessoa_nf, gerar_nf_cli_bloqueado, id_base_geracao_nf, status_nf_financeiro,
             vencimento_inicial_financeiro, vencimento_final_financeiro, forma_recebimento_financeiro,
             condicao_pagamento, status_geracao_nf, desc_filtro_lote, numero_lote_cancelar,
             modelo_nf_geracao, tipo_geracao_lote, ramal_voip, gerar_nf_voip, data_lancamento_voip,
             vencimento_pos_pago_voip, data_inicial_ligacoes_voip, data_final_ligacoes_voip,
             data_inicial_venciemnto_voip, data_final_venciemnto_voip, id_condicao_pagamento_voip,
             data_emissao_nf_voip, momento_ini_geracao, momento_fin_geracao, modelo_nf, filial_id)
            VALUES
            (%s,%s,%s,1,0,0,NULL,'T','S',2,'T',
             %s,%s,'A',0,1,%s,0,5,1,0,
             1,1969,NULL,NULL,NULL,NULL,NULL,0,NULL,
             NULL,NULL,'62',1)
        """, (novo_lote_id, hoje, u_dia, p_dia, u_dia, desc))

    with get_conn() as conn:
        conn.execute("UPDATE batch_run SET id_lote_ixc=? WHERE id=?", (novo_lote_id, batch_id))
        conn.commit()

# ── REGRAS FISCAIS ────────────────────────────────────────────

@router.get("/regras")
def listar_regras(user=Depends(requer_admin)):
    with get_conn() as conn:
        rows = get_conn().execute("SELECT * FROM regras_fiscais ORDER BY tipo_pessoa, id_tipo_cliente").fetchall()
    return {"regras": [dict(r) for r in rows]}

class RegraIn(BaseModel):
    tipo_pessoa:     str
    id_tipo_cliente: int
    tipo_documento:  int
    descricao:       Optional[str] = None
    ativo:           int = 1

@router.post("/regras")
def criar_regra(body: RegraIn, user=Depends(requer_admin)):
    with get_conn() as conn:
        try:
            conn.execute("""
                INSERT INTO regras_fiscais (tipo_pessoa, id_tipo_cliente, tipo_documento, descricao, ativo)
                VALUES (?, ?, ?, ?, ?)
            """, (body.tipo_pessoa, body.id_tipo_cliente, body.tipo_documento, body.descricao, body.ativo))
            conn.commit()
        except Exception:
            raise HTTPException(400, "Regra já existe para este tipo/cliente")
    return {"ok": True}

@router.put("/regras/{rid}")
def editar_regra(rid: int, body: RegraIn, user=Depends(requer_admin)):
    with get_conn() as conn:
        conn.execute("""
            UPDATE regras_fiscais
            SET tipo_pessoa=?, id_tipo_cliente=?, tipo_documento=?, descricao=?, ativo=?
            WHERE id=?
        """, (body.tipo_pessoa, body.id_tipo_cliente, body.tipo_documento, body.descricao, body.ativo, rid))
        conn.commit()
    return {"ok": True}

@router.delete("/regras/{rid}")
def deletar_regra(rid: int, user=Depends(requer_admin)):
    with get_conn() as conn:
        conn.execute("DELETE FROM regras_fiscais WHERE id=?", (rid,))
        conn.commit()
    return {"ok": True}

# ── TETO DE FATURAMENTO ───────────────────────────────────────

@router.get("/teto")
def get_teto(user=Depends(requer_admin)):
    # Média mensal 2025 do IXC
    with conn_ixc() as ixc:
        cur = ixc.cursor(dictionary=True)
        cur.execute("""
            SELECT AVG(valor_total_mes) AS media_mensal
            FROM (
                SELECT DATE_FORMAT(vs.data_emissao,'%%Y-%%m') AS mes_ano,
                       SUM(vs.valor_produtos) AS valor_total_mes
                FROM vd_saida vs
                WHERE vs.status <> 'C'
                  AND vs.data_emissao BETWEEN '2025-01-01' AND '2025-12-31'
                  AND (
                    (MONTH(vs.data_emissao) BETWEEN 1 AND 10 AND vs.modelo_nf IN (21,'ND'))
                    OR
                    (MONTH(vs.data_emissao) IN (11,12) AND vs.modelo_nf = 62)
                  )
                GROUP BY DATE_FORMAT(vs.data_emissao,'%%Y-%%m')
            ) t
        """)
        row = cur.fetchone()
        media = round(float(row["media_mensal"] or 0), 2)

    with get_conn() as conn:
        cur = conn.cursor()
        cur.execute("SELECT valor FROM hf_config WHERE chave='teto_faturamento'")
        row = cur.fetchone()
        teto = float(row["valor"]) if row else media

    return {"media_mensal": media, "teto": teto}

class TetoIn(BaseModel):
    teto: float

@router.post("/teto")
def salvar_teto(body: TetoIn, user=Depends(requer_admin)):
    with get_conn() as conn:
        conn.execute("""
            INSERT OR REPLACE INTO hf_config (chave, valor, descricao)
            VALUES ('teto_faturamento', ?, 'Teto máximo de faturamento mensal')
        """, (str(body.teto),))
        conn.commit()
    return {"ok": True}

# ── AUDITORIA ─────────────────────────────────────────────────

@router.get("/auditoria")
def auditoria(user=Depends(requer_admin)):
    with get_conn() as conn:
        cur = conn.cursor()
        cur.execute("""
            SELECT id, mes_ref, status, qtd_itens, total_simulado,
                   created_by, created_at, approved_by, approved_at, id_lote_ixc
            FROM batch_run
            ORDER BY created_at DESC
        """)
        rows = cur.fetchall()
    return {"batches": [dict(r) for r in rows]}
