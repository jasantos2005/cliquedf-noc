# -*- coding: utf-8 -*-
from fastapi import APIRouter, HTTPException, Depends
from pydantic import BaseModel
from typing import Optional
from datetime import datetime
from app.core.auth      import requer_operador
from app.core.db        import get_conn
from app.services.pet   import resumo_pet, listar_novos
from app.services.simulacao import simular, solicitar_aprovacao, SimulacaoError

router = APIRouter(prefix="/api/operador")

@router.get("/dashboard")
def dashboard(user=Depends(requer_operador)):
    mes_ref = datetime.now().strftime("%Y-%m")
    resumo  = resumo_pet(mes_ref)
    novos   = listar_novos(mes_ref)

    with get_conn() as conn:
        cur = conn.cursor()
        cur.execute("""
            SELECT id, mes_ref, status, qtd_itens, total_simulado, created_at
            FROM batch_run WHERE mes_ref = ?
        """, (mes_ref,))
        batch = cur.fetchone()

    return {
        "mes_ref":          mes_ref,
        "saldo_disponivel": resumo["saldo_disponivel"],
        "qtd_elegiveis":    len(novos),
        "batch":            dict(batch) if batch else None,
    }

@router.get("/simular")
def tela_simulacao(mes_ref: Optional[str] = None, user=Depends(requer_operador)):
    if not mes_ref:
        mes_ref = datetime.now().strftime("%Y-%m")
    resumo  = resumo_pet(mes_ref)
    novos   = listar_novos(mes_ref)

    with get_conn() as conn:
        cur = conn.cursor()
        cur.execute("SELECT * FROM batch_run WHERE mes_ref=?", (mes_ref,))
        batch = cur.fetchone()

    return {
        "mes_ref":    mes_ref,
        "resumo_pet": resumo,
        "elegiveis":  novos,
        "batch":      dict(batch) if batch else None,
    }

class SimularIn(BaseModel):
    quantidade: int
    mes_ref:    Optional[str] = None

@router.post("/simular")
def executar_simulacao(body: SimularIn, user=Depends(requer_operador)):
    try:
        return simular(
            quantidade=body.quantidade,
            usuario=user["login"],
            mes_ref=body.mes_ref,
        )
    except SimulacaoError as e:
        raise HTTPException(400, str(e))

class AprovacaoIn(BaseModel):
    batch_id: int

@router.post("/solicitar-aprovacao")
def solicitar(body: AprovacaoIn, user=Depends(requer_operador)):
    try:
        return solicitar_aprovacao(body.batch_id, user["login"])
    except SimulacaoError as e:
        raise HTTPException(400, str(e))

@router.get("/historico")
def historico(user=Depends(requer_operador)):
    with get_conn() as conn:
        cur = conn.cursor()
        cur.execute("""
            SELECT id, mes_ref, status, qtd_itens, total_simulado,
                   created_by, created_at, approved_by, approved_at, id_lote_ixc
            FROM batch_run
            ORDER BY created_at DESC
            LIMIT 24
        """)
        rows = cur.fetchall()
    return {"batches": [dict(r) for r in rows]}

@router.get("/batch/{batch_id}/contratos")
def contratos_batch(batch_id: int, user=Depends(requer_operador)):
    with get_conn() as conn:
        cur = conn.cursor()
        cur.execute("""
            SELECT id_contrato, id_cliente, valor, created_at
            FROM batch_items WHERE batch_id=?
        """, (batch_id,))
        rows = cur.fetchall()
    return {"contratos": [dict(r) for r in rows]}
