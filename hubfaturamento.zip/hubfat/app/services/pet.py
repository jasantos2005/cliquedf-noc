# -*- coding: utf-8 -*-
from typing import List, Dict
from datetime import date, timedelta
from app.core.db_ixc import conn_ixc

def _intervalo_mes(mes_ref: str):
    ano, mes = mes_ref.split("-")
    primeiro = f"{ano}-{mes}-01"
    ultimo   = (date(int(ano), int(mes), 1) + timedelta(days=32)).replace(day=1) - timedelta(days=1)
    return primeiro, ultimo.strftime("%Y-%m-%d")

def resumo_pet(mes_ref: str) -> Dict:
    primeiro, ultimo = _intervalo_mes(mes_ref)
    with conn_ixc() as conn:
        cur = conn.cursor(dictionary=True)
        cur.execute("""
            SELECT COALESCE(SUM(valor_aberto), 0) AS saldo_disponivel
            FROM fn_areceber
            WHERE data_vencimento BETWEEN %s AND %s
              AND status IN ('A', 'R')
        """, (primeiro, ultimo))
        row = cur.fetchone()
    saldo = float(row["saldo_disponivel"] or 0)
    return {
        "saldo_disponivel": round(saldo, 2),
        "valor_base":       round(saldo, 2),
        "mes_ref":          mes_ref,
    }

def listar_novos(mes_ref: str) -> List[Dict]:
    primeiro, ultimo = _intervalo_mes(mes_ref)
    with conn_ixc() as conn:
        cur = conn.cursor(dictionary=True)
        cur.execute("""
            SELECT
                cc.id                                   AS id_contrato,
                c.id                                    AS id_cliente,
                c.razao,
                cc.data_ativacao,
                COALESCE(SUM(t.valor_aberto), 0)        AS valor_boleto
            FROM cliente_contrato cc
            JOIN cliente c ON c.id = cc.id_cliente
            LEFT JOIN fn_areceber t
                ON  t.id_contrato    = cc.id
                AND t.data_vencimento BETWEEN %s AND %s
                AND t.status IN ('A', 'R')
            WHERE cc.status = 'A'
              AND cc.data_ativacao >= '2025-11-01'
              AND cc.id NOT IN (
                  SELECT id_contrato FROM vd_saida
                  WHERE data_emissao BETWEEN %s AND %s
                    AND status != 'C'
              )
            GROUP BY cc.id, c.id, c.razao, cc.data_ativacao
            HAVING valor_boleto > 0
            ORDER BY c.razao
        """, (primeiro, ultimo, primeiro, ultimo))
        rows = cur.fetchall()
    return [dict(r) for r in rows]
