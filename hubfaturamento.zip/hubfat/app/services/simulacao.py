# -*- coding: utf-8 -*-
from datetime import datetime
from typing import Dict, List, Optional
from app.core.db import get_conn
from app.services.pet import resumo_pet, listar_novos

class SimulacaoError(Exception):
    pass

def _obter_ou_criar_batch(mes_ref: str, usuario: str) -> int:
    with get_conn() as conn:
        cur = conn.cursor()
        cur.execute("SELECT id, status FROM batch_run WHERE mes_ref = ?", (mes_ref,))
        row = cur.fetchone()
        if row:
            batch_id = row["id"]
            status   = row["status"]
            if status in ("AGUARDANDO_APROVACAO", "APROVADO", "APLICADO"):
                raise SimulacaoError(
                    f"Simulação do mês {mes_ref} já está em status: {status.replace('_',' ').title()}"
                )
            if status == "REJEITADO":
                # Permite resiimular se rejeitado
                cur.execute("DELETE FROM batch_items WHERE batch_id = ?", (batch_id,))
                cur.execute("UPDATE batch_run SET status='SIMULADO', created_by=?, created_at=? WHERE id=?",
                            (usuario, datetime.now(), batch_id))
            else:
                cur.execute("DELETE FROM batch_items WHERE batch_id = ?", (batch_id,))
        else:
            cur.execute("""
                INSERT INTO batch_run (mes_ref, status, created_by, created_at)
                VALUES (?, 'SIMULADO', ?, ?)
            """, (mes_ref, usuario, datetime.now()))
            batch_id = cur.lastrowid
        conn.commit()
        return batch_id

def simular(quantidade: int, usuario: str, mes_ref: Optional[str] = None) -> Dict:
    if mes_ref is None:
        mes_ref = datetime.now().strftime("%Y-%m")

    resumo    = resumo_pet(mes_ref)
    elegiveis = listar_novos(mes_ref)

    if quantidade <= 0:
        raise SimulacaoError("Quantidade deve ser maior que zero.")
    if quantidade > len(elegiveis):
        raise SimulacaoError(
            f"Solicitado {quantidade} mas só há {len(elegiveis)} elegível(eis)."
        )

    selecionados = elegiveis[:quantidade]
    total        = sum(float(i["valor_boleto"]) for i in selecionados)

    if total > resumo["saldo_disponivel"]:
        raise SimulacaoError(
            f"Valor total R$ {total:,.2f} excede saldo disponível R$ {resumo['saldo_disponivel']:,.2f}."
        )

    batch_id = _obter_ou_criar_batch(mes_ref, usuario)

    with get_conn() as conn:
        cur = conn.cursor()
        for item in selecionados:
            cur.execute("""
                INSERT INTO batch_items (batch_id, id_contrato, id_cliente, valor)
                VALUES (?, ?, ?, ?)
            """, (batch_id, item["id_contrato"], item["id_cliente"], float(item["valor_boleto"])))
        cur.execute("""
            UPDATE batch_run SET qtd_itens=?, total_simulado=? WHERE id=?
        """, (len(selecionados), total, batch_id))
        conn.commit()

    return {
        "batch_id":    batch_id,
        "mes_ref":     mes_ref,
        "resumo_pet":  resumo,
        "contratos":   selecionados,
        "total_novos": round(total, 2),
        "saldo_apos":  round(resumo["saldo_disponivel"] - total, 2),
        "status":      "SIMULADO",
    }

def solicitar_aprovacao(batch_id: int, usuario: str) -> Dict:
    with get_conn() as conn:
        cur = conn.cursor()
        cur.execute("SELECT status, mes_ref, total_simulado FROM batch_run WHERE id=?", (batch_id,))
        row = cur.fetchone()
        if not row:
            raise SimulacaoError("Batch não encontrado.")
        if row["status"] != "SIMULADO":
            raise SimulacaoError("Só é possível solicitar aprovação no status SIMULADO.")
        cur.execute("UPDATE batch_run SET status='AGUARDANDO_APROVACAO' WHERE id=?", (batch_id,))
        conn.commit()

    from app.services.telegram import enviar_notificacao_aprovacao
    try:
        enviar_notificacao_aprovacao(
            batch_id=batch_id,
            valor_simulacao=float(row["total_simulado"] or 0),
            mes_ref=row["mes_ref"],
        )
    except Exception:
        pass

    return {
        "batch_id": batch_id,
        "status":   "AGUARDANDO_APROVACAO",
        "mensagem": "Simulação enviada para aprovação com sucesso.",
    }
