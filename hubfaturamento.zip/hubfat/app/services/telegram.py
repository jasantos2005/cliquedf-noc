# -*- coding: utf-8 -*-
import requests
import os

BASE_URL = os.getenv("HUBFAT_URL", "http://191.252.196.225:8010")

def enviar_notificacao_aprovacao(batch_id: int, valor_simulacao: float, mes_ref: str):
    token   = os.getenv("TELEGRAM_BOT_TOKEN")
    chat_id = os.getenv("TELEGRAM_ADMIN_CHAT_ID")
    if not token or not chat_id:
        return

    msg = (
        f"🧾 <b>NOVA SIMULAÇÃO AGUARDANDO APROVAÇÃO</b>\n\n"
        f"📅 Mês: <b>{mes_ref}</b>\n"
        f"🔢 Batch ID: <b>{batch_id}</b>\n"
        f"💰 Valor: <b>R$ {valor_simulacao:,.2f}</b>\n\n"
        f"Acesse o painel para aprovar ou rejeitar."
    )

    payload = {
        "chat_id":    chat_id,
        "text":       msg,
        "parse_mode": "HTML",
        "reply_markup": {
            "inline_keyboard": [[
                {"text": "✅ Aprovar",  "url": f"{BASE_URL}/api/admin/aprovar-link?batch_id={batch_id}&acao=aprovar&token={os.getenv('TELEGRAM_APPROVE_TOKEN','')}"},
                {"text": "❌ Rejeitar", "url": f"{BASE_URL}/api/admin/aprovar-link?batch_id={batch_id}&acao=rejeitar&token={os.getenv('TELEGRAM_APPROVE_TOKEN','')}"},
            ]]
        }
    }

    try:
        requests.post(f"https://api.telegram.org/bot{token}/sendMessage", json=payload, timeout=5)
    except Exception:
        pass
