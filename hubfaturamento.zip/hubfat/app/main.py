# -*- coding: utf-8 -*-
import os
from dotenv import load_dotenv
load_dotenv()

from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
from app.core.db       import init_db
from app.routes        import auth, operador, admin

app = FastAPI(title="Hub Faturamento", version="1.0")

@app.on_event("startup")
def startup():
    init_db()
    print("[HubFat] Iniciado na porta 8010")

# Routers
app.include_router(auth.router)
app.include_router(operador.router)
app.include_router(admin.router)

# Static
app.mount("/static", StaticFiles(directory="static"), name="static")

@app.get("/")
def index():
    return FileResponse("static/app.html")

@app.get("/health")
def health():
    return {"status": "ok", "app": "hubfaturamento"}
