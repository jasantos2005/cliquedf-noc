# -*- coding: utf-8 -*-
import mysql.connector
from mysql.connector import MySQLConnection
from contextlib import contextmanager
import os
from typing import Generator

def get_ixc_config() -> dict:
    return {
        "host":     os.getenv("IXC_HOST",     "45.176.16.23"),
        "port":     int(os.getenv("IXC_PORT", 3306)),
        "user":     os.getenv("IXC_USER",     "escrita"),
        "password": os.getenv("IXC_PASSWORD", "8CksUSiJeZksacTVNX7y"),
        "database": os.getenv("IXC_DATABASE", "ixcprovedor"),
        "autocommit":         True,
        "charset":            "utf8mb4",
        "use_unicode":        True,
        "connection_timeout": 10,
        "raise_on_warnings":  False,
    }

@contextmanager
def conn_ixc() -> Generator[MySQLConnection, None, None]:
    conn = None
    try:
        conn = mysql.connector.connect(**get_ixc_config())
        yield conn
    except mysql.connector.Error as err:
        raise ConnectionError(f"Falha na conexão com o IXC: {err}")
    finally:
        if conn and conn.is_connected():
            conn.close()

def test_connection() -> bool:
    try:
        with conn_ixc() as conn:
            conn.cursor().execute("SELECT 1")
            return True
    except Exception:
        return False
