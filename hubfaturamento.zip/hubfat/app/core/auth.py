# -*- coding: utf-8 -*-
import hashlib
import os
from datetime import datetime, timedelta
from typing import Optional

from fastapi import Depends, HTTPException, status
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
import jwt

SECRET_KEY = os.getenv("SECRET_KEY", "hubfat_secret_2026")
ALGORITHM  = "HS256"
EXPIRE_H   = int(os.getenv("SESSION_MAX_AGE", 8))

security = HTTPBearer()

def hash_senha(senha: str) -> str:
    return hashlib.sha256(senha.encode()).hexdigest()

def criar_token(payload: dict) -> str:
    data = payload.copy()
    data["exp"] = datetime.utcnow() + timedelta(hours=EXPIRE_H)
    return jwt.encode(data, SECRET_KEY, algorithm=ALGORITHM)

def decodificar_token(token: str) -> Optional[dict]:
    try:
        return jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
    except Exception:
        return None

def get_usuario_atual(creds: HTTPAuthorizationCredentials = Depends(security)):
    payload = decodificar_token(creds.credentials)
    if not payload:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Token inválido")
    return payload

def requer_operador(user=Depends(get_usuario_atual)):
    if user.get("nivel", 0) < 10:
        raise HTTPException(status_code=403, detail="Acesso negado")
    return user

def requer_admin(user=Depends(get_usuario_atual)):
    if user.get("nivel", 0) < 99:
        raise HTTPException(status_code=403, detail="Acesso de administrador necessário")
    return user
