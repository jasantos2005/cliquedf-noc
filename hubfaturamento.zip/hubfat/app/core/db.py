# -*- coding: utf-8 -*-
import sqlite3
import os
from pathlib import Path

DB_PATH = os.getenv("DB_PATH", "/opt/automacoes/cliquedf/faturamento/portal.db")

def get_conn():
    conn = sqlite3.connect(DB_PATH, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn

def init_db():
    Path(DB_PATH).parent.mkdir(parents=True, exist_ok=True)

    with get_conn() as conn:
        cur = conn.cursor()

        # Grupos de acesso
        cur.execute("""
            CREATE TABLE IF NOT EXISTS hf_grupos (
                id      INTEGER PRIMARY KEY AUTOINCREMENT,
                nome    TEXT NOT NULL UNIQUE,
                nivel   INTEGER NOT NULL DEFAULT 10
            )
        """)

        # Usuários
        cur.execute("""
            CREATE TABLE IF NOT EXISTS hf_usuarios (
                id           INTEGER PRIMARY KEY AUTOINCREMENT,
                nome         TEXT NOT NULL,
                login        TEXT NOT NULL UNIQUE,
                senha_hash   TEXT NOT NULL,
                id_grupo     INTEGER NOT NULL DEFAULT 1,
                ativo        INTEGER NOT NULL DEFAULT 1,
                criado_em    DATETIME DEFAULT CURRENT_TIMESTAMP,
                ultimo_acesso DATETIME,
                FOREIGN KEY (id_grupo) REFERENCES hf_grupos(id)
            )
        """)

        # Batch principal
        cur.execute("""
            CREATE TABLE IF NOT EXISTS batch_run (
                id              INTEGER PRIMARY KEY AUTOINCREMENT,
                mes_ref         TEXT NOT NULL UNIQUE,
                status          TEXT NOT NULL DEFAULT 'SIMULADO',
                qtd_itens       INTEGER DEFAULT 0,
                total_simulado  REAL DEFAULT 0.0,
                created_at      DATETIME DEFAULT CURRENT_TIMESTAMP,
                created_by      TEXT NOT NULL,
                approved_by     TEXT,
                approved_at     DATETIME,
                applied_at      DATETIME,
                id_lote_ixc     INTEGER
            )
        """)

        # Itens do batch
        cur.execute("""
            CREATE TABLE IF NOT EXISTS batch_items (
                id           INTEGER PRIMARY KEY AUTOINCREMENT,
                batch_id     INTEGER NOT NULL,
                id_contrato  INTEGER NOT NULL,
                id_cliente   INTEGER NOT NULL,
                valor        REAL NOT NULL,
                created_at   DATETIME DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (batch_id) REFERENCES batch_run(id) ON DELETE CASCADE
            )
        """)

        # Regras fiscais
        cur.execute("""
            CREATE TABLE IF NOT EXISTS regras_fiscais (
                id              INTEGER PRIMARY KEY AUTOINCREMENT,
                tipo_pessoa     TEXT NOT NULL,
                id_tipo_cliente INTEGER NOT NULL,
                descricao       TEXT,
                tipo_documento  INTEGER NOT NULL,
                ativo           INTEGER DEFAULT 1,
                UNIQUE(tipo_pessoa, id_tipo_cliente)
            )
        """)

        # Config geral (teto de faturamento etc.)
        cur.execute("""
            CREATE TABLE IF NOT EXISTS hf_config (
                chave    TEXT PRIMARY KEY,
                valor    TEXT NOT NULL,
                descricao TEXT
            )
        """)

        # Índices
        cur.execute("CREATE INDEX IF NOT EXISTS idx_batch_mes    ON batch_run(mes_ref)")
        cur.execute("CREATE INDEX IF NOT EXISTS idx_batch_status ON batch_run(status)")

        # Grupos padrão
        cur.execute("INSERT OR IGNORE INTO hf_grupos (id, nome, nivel) VALUES (1, 'operador', 10)")
        cur.execute("INSERT OR IGNORE INTO hf_grupos (id, nome, nivel) VALUES (2, 'admin',    99)")

        # Admin padrão (senha: admin123)
        import hashlib
        senha_hash = hashlib.sha256("admin123".encode()).hexdigest()
        cur.execute("""
            INSERT OR IGNORE INTO hf_usuarios (nome, login, senha_hash, id_grupo)
            VALUES ('Administrador', 'admin', ?, 2)
        """, (senha_hash,))

        conn.commit()

    print(f"[HubFat] Banco inicializado: {DB_PATH}")
